/**
 * 
 */
/**
 * 
 */
module JSONParseFIWXDX {
	requires json.simple;
}